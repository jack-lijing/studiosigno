﻿IPAmj明朝フォント
― はじめにお読みください ―

IPAmj明朝フォントは、ISO/IEC10646に準拠したTrueTypeベースのOpenTypeフォントです。

IPAmj明朝フォントの使用または利用に当たっては、添付の「IPAフォントライセンスv1.0」に定める条件に従ってください。
IPAmj明朝フォントを使用し、複製し、または頒布する行為、その他、「IPAフォントライセンスv1.0」に定める権利の利用を行った場合、受領者は「IPAフォントライセンスv1.0」に同意したものと見なします。


IPAmj明朝   ipamjm00301.zip
|--はじめにお読みください   Readme_ipamjm003.01.txt
|--IPAフォントライセンスv1.0   IPA_Font_License_Agreement_v1.0.txt
|--IPAmj明朝（Ver.003.01）   ipamjm.ttf


「IPAフォント」は、IPAの登録商標です。

